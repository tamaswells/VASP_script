The updated VASPKIT manual (Chinese edition) can be viewed on the website: 
    https://tamaswells.github.io/VASPKIT_manual/manual0.73/vaspkit-manual-0.73.html

The updated VASPKIT manual (Chinese edition of PDF format) can be downloaded from the following repository:
    https://github.com/tamaswells/VASPKIT_manual
