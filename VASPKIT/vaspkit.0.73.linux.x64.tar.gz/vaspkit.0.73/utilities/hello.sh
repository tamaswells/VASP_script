#!/bin/bash
echo "I love you"
