#ifndef __USEFUL_TOOL__
#define __USEFUL_TOOL__
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
using std::string;
using std::vector;
using std::cout;
using std::endl;
using std::stringstream;

//using namespace std;

string& trim(string& s){
    if(s.empty())return s;
    s.erase(0, s.find_first_not_of(' '));
    s.erase(s.find_last_not_of(' ') + 1);
    return s;
}

void split(string& s, string& delim, vector<string>* ret){
    size_t last = 0;
    size_t index = s.find_first_of(delim, last);
    while(index != string::npos){//说明查找没有匹配
        ret->push_back(s.substr(last, index-last));
        while (s[++index]==delim[0]){
        }        
        last = index;
        index = s.find_first_of(delim, last);
    }
    if(index - last > 0)ret->push_back(s.substr(last, index-last));
}

template <typename parsedata>
inline void parsenum(string &s,parsedata &rets){
    stringstream tmps;
    tmps.clear();
    tmps<<s;
    tmps>>rets;
    }

template <typename splited_data>
inline void split_data(string& s,vector<splited_data>* ret){
    stringstream tmps;
    splited_data ret_data;
    ret->clear(); 
    tmps.clear();
    tmps<<s;
    tmps>>ret_data; 
    ret->push_back(ret_data);  
    while (tmps>>ret_data){
    ret->push_back(ret_data);
    }
}

#endif
