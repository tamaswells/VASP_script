#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <iostream>
#include <fstream>
#include <string>
#include "useful_tools.h"
#include "Eigen/Eigen"
#include <cmath>


using namespace std;
using namespace Eigen;

class OUTCAR{
    public:
        vector<int> each_element_num;
        vector<string> each_element;
        vector<string> each_element_set;
        Vector3d L; // box lengths
        Vector3d L_times_pbc; // boundary conditions
        Matrix<double,Dynamic,3> Lattice;
        ifstream FILEs;
        FILE * gro;
        int ions_num;
        string each_line;
        //bool read_atoms_num;
        Matrix<double,Dynamic,6> atomic_coord_force;
        Matrix<double,Dynamic,3> atomic_coord_prev;
        Matrix<double,Dynamic,3> atomic_coord_prve_unwrap;
        Matrix<double,Dynamic,3> atomic_velocity;
        Matrix<double,Dynamic,3> atomic_dr;
        double dt;

        OUTCAR(const string &file);
        void write2GRO(int &frame);
        bool Info_read();
        void atom_num_read();
        ~OUTCAR();
        void Process();
};

OUTCAR::OUTCAR(const string &file){
    //dt=0.5;
    FILEs.open(file.data());
    if (!FILEs){
        cout<<"Error,no OUTCAR!"<<endl;
        abort();
    }
    this->atom_num_read();
    FILEs.seekg(0,ios::beg);
    atomic_coord_force= MatrixXd::Zero(ions_num,6);
    atomic_velocity = MatrixXd::Zero(ions_num,3);
    Lattice= MatrixXd::Zero(3,3);
    atomic_dr=MatrixXd::Zero(ions_num,3);
    atomic_coord_prev=MatrixXd::Zero(ions_num,3);
    atomic_coord_prve_unwrap=MatrixXd::Zero(ions_num,3);
    L_times_pbc<<1,1,1;
    gro=fopen("XDATCAR.gro","w"); 
}

void OUTCAR::atom_num_read(){
    unsigned int i,j;
    vector<string> tmp;
    string delim(" ");
    string keyword("NIONS =");
    do{
        getline(FILEs,each_line);
    } while(each_line.find(keyword)==string::npos);
    each_line=each_line.substr(each_line.find(keyword)+7);
    parsenum(each_line,ions_num);
    FILEs.seekg(0,ios::beg);
    keyword="POTIM  =";
    do{
        getline(FILEs,each_line);
    } while(each_line.find(keyword)==string::npos);
    split(trim(each_line),delim,&tmp);
    parsenum(tmp[2],dt);
    tmp.clear();
    FILEs.seekg(0,ios::beg);
    keyword="ions per type";
    do{
        getline(FILEs,each_line);
    } while(each_line.find(keyword)==string::npos);
    each_line=each_line.substr(each_line.find(keyword)+20);
    split_data(each_line,&each_element_num);
    //cout<<each_element_num[1]<<endl;
    FILEs.seekg(0,ios::beg);
    keyword="TITEL";
    tmp.clear();
    for (i=0;i<each_element_num.size();i++){
        do{
            getline(FILEs,each_line);
        } while(each_line.find(keyword)==string::npos);
        split(trim(each_line),delim,&tmp);
        each_element.push_back(tmp[3]);
        tmp.clear();
        //cout<<each_element[i]<<endl;
    }
    for (i=0;i<each_element_num.size();i++){
        for (j=0;j<each_element_num[i];j++){
            each_element_set.push_back(each_element[i]);
        }
    }    
}

bool OUTCAR::Info_read(){
    string keyword_lattice("direct lattice vectors");
    string keyword_position("POSITION");
    bool ret=true;
    bool lattice_found=false;
    bool position_found=false;
    unsigned int i=0,j=0;
    vector<double> lattices;
    do{
        if (!getline(FILEs,each_line)) {
            ret=false;
            return ret;
        }
        if (each_line.find(keyword_lattice)!=string::npos){
            lattice_found=true;
            for (i=0;i<3;i++){
                getline(FILEs,each_line);
                split_data(each_line,&lattices);
                for (j=0;j<3;j++){
                    Lattice(i,j)=lattices[j];
                }
            }
            //cout<<Lattice<<endl;
        }
        else if (each_line.find(keyword_position)!=string::npos){
            position_found=true;
            getline(FILEs,each_line);
            for (i=0;i<ions_num;i++){
                getline(FILEs,each_line);
                split_data(each_line,&lattices);
                for (j=0;j<6;j++){
                    atomic_coord_force(i,j)=lattices[j];
                }
            }
            //cout<<atomic_coord_force<<endl;
        }
    } while(!lattice_found || !position_found); 
    return ret;   
}

OUTCAR::~OUTCAR(){
    FILEs.close();
    fclose(gro);
}

void OUTCAR::write2GRO(int &frame){
    unsigned int i;
    int index=1;
    fprintf(gro,"t= %3.1f\n",dt*frame);
    fprintf(gro,"%5d\n",ions_num);
    // A/fs  ? ---> velocity (in nm/ps (or km/s)
    atomic_coord_prev=atomic_coord_prev/10.0; //A to nm
    atomic_velocity=atomic_velocity*100.0; //A/fs ->nm/ps  
    for (i=0;i<ions_num;i++){
        fprintf(gro,"%5d%-5s%5s%5d%8.3f%8.3f%8.3f%8.4f%8.4f%8.4f\n",index,"MOL",\
        each_element_set[i].data(),index,atomic_coord_prev(i,0),atomic_coord_prev(i,1)\
        ,atomic_coord_prev(i,2),atomic_velocity(i,0),atomic_velocity(i,1),atomic_velocity(i,2));
        index+=1;
    }
    Lattice=Lattice/10.0; //A to nm    
    fprintf(gro,"%8.4f%8.4f%8.4f%8.4f%8.4f%8.4f%8.4f%8.4f%8.4f\n",Lattice(0,0),Lattice(1,1),\
    Lattice(2,2),0.0,0.0,Lattice(1,0),0.0,Lattice(2,0),Lattice(2,1));
    //v1(x) v2(y) v3(z) v1(y) v1(z) v2(x) v2(z) v3(x) v3(y), the last 6 values may be omitted (they will be set to zero). GROMACS only supports boxes with v1(y)=v1(z)=v2(z)=0.
    atomic_coord_prev=atomic_coord_prev*10.0; // nm to A
}

void OUTCAR::Process(){
    unsigned int i,j;
    int frame=0;
    this->Info_read();
    atomic_coord_prev=atomic_coord_force.block(0,0,ions_num,3); //initial
    atomic_coord_prve_unwrap=atomic_coord_force.block(0,0,ions_num,3);//fake coord
    while(this->Info_read()){
        //cout<<atomic_coord_force.block(0,0,ions_num,3)<<endl;
        atomic_dr=atomic_coord_force.block(0,0,ions_num,3)-atomic_coord_prve_unwrap; //dr
        atomic_coord_prve_unwrap=atomic_coord_force.block(0,0,ions_num,3);//To record fake coord
        for (i=0;i<3;i++){
            L[i]=sqrt(pow(Lattice(i,0),2)+pow(Lattice(i,1),2)+pow(Lattice(i,2),2));
        }
        //unwrap the coordinates and get the velocities:
        for (i=0;i<ions_num;i++){
            for (j=0;j<3;j++){
                atomic_dr(i,j)=atomic_dr(i,j)-round(atomic_dr(i,j)/L[j])*L_times_pbc[j]*L[j];
            }
        }        
        atomic_coord_prev=atomic_coord_prev+atomic_dr;
        atomic_velocity=atomic_dr/dt; //A/fs
        this->write2GRO(++frame);
    };
    //http://blog.sciencenet.cn/blog-3102863-1159419.html
}

int main(int argc,char * argv[]){
    string file("OUTCAR");
    OUTCAR myOUTCAR(file);
    myOUTCAR.Process();
    return 0;
}
