#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <iostream>
#include <fstream>
#include <string>
#include "useful_tools.h"
#include "Eigen/Eigen"
#include <cmath>


using namespace std;
using namespace Eigen;

class OUTCAR{
    public:
        vector<int> each_element_num;
        vector<double> each_element_mass;
        vector<string> each_element;
        vector<string> each_element_set;
        Vector3d L; // box lengths
        Vector3d L_times_pbc; // boundary conditions
        Matrix<double,Dynamic,3> Lattice;
        ifstream FILEs;
        FILE * gro;
        FILE * top;
        FILE * mdp;
        int ions_num;
        string each_line;
        //bool read_atoms_num;
        Matrix<double,Dynamic,6> atomic_coord_force;
        Matrix<double,Dynamic,3> atomic_coord_prev;
        Matrix<double,Dynamic,3> atomic_coord_prve_unwrap;
        Matrix<double,Dynamic,3> atomic_velocity;
        Matrix<double,Dynamic,3> atomic_dr;
        double dt;

        OUTCAR(const string &file);
        void write2GRO(int &frame);
        void writetopo();
        bool Info_read();
        void atom_num_read();
        ~OUTCAR();
        void Process();
};

OUTCAR::OUTCAR(const string &file){
    //dt=0.5;
    FILEs.open(file.data());
    if (!FILEs){
        cout<<"Error,no OUTCAR!"<<endl;
        abort();
    }
    this->atom_num_read();
    FILEs.seekg(0,ios::beg);
    atomic_coord_force= MatrixXd::Zero(ions_num,6);
    atomic_velocity = MatrixXd::Zero(ions_num,3);
    Lattice= MatrixXd::Zero(3,3);
    atomic_dr=MatrixXd::Zero(ions_num,3);
    atomic_coord_prev=MatrixXd::Zero(ions_num,3);
    atomic_coord_prve_unwrap=MatrixXd::Zero(ions_num,3);
    L_times_pbc<<1,1,1;
    gro=fopen("XDATCAR.gro","w"); 
    top=fopen("XDATCAR.top","w");
    mdp=fopen("XDATCAR.mdp","w");
}

void OUTCAR::atom_num_read(){
    unsigned int i,j;
    vector<string> tmp;
    string delim(" ");

    string keyword("Mass of Ions in am");
    do{
        getline(FILEs,each_line);
    } while(each_line.find(keyword)==string::npos);
    getline(FILEs,each_line);
    //parsenum(each_line,ions_num);
    tmp.clear();
    split(trim(each_line),delim,&tmp);
    for (i=2;i<tmp.size();i++){
        parsenum(tmp[i],dt); //暂时储存质量
        each_element_mass.push_back(dt);
        //cout<<dt<<endl;
    }
    tmp.clear();
    dt=1.0;
    FILEs.seekg(0,ios::beg);
    keyword="POTIM  =";
    do{
        getline(FILEs,each_line);
    } while(each_line.find(keyword)==string::npos);
    split(trim(each_line),delim,&tmp);
    parsenum(tmp[2],dt);
    tmp.clear();
    FILEs.seekg(0,ios::beg);
    keyword="ions per type";
    do{
        getline(FILEs,each_line);
    } while(each_line.find(keyword)==string::npos);
    each_line=each_line.substr(each_line.find(keyword)+20);
    split_data(each_line,&each_element_num);
    ions_num=0;
    for (i=0;i<each_element_num.size();i++){
        ions_num=ions_num+each_element_num[i];
    }
    //cout<<ions_num<<endl;
    FILEs.seekg(0,ios::beg);
    keyword="POTCAR:";
    tmp.clear();
    for (i=0;i<each_element_num.size();i++){
        do{
            getline(FILEs,each_line);
        } while(each_line.find(keyword)==string::npos);
        split(trim(each_line),delim,&tmp);
        each_element.push_back(tmp[2]);
        tmp.clear();
        //cout<<each_element[i]<<endl;
    }
    keyword="_";
    for (i=0;i<each_element_num.size();i++){
        for (j=0;j<each_element_num[i];j++){
            if (each_element[i].find(keyword)!=string::npos){
                each_element[i]=each_element[i].substr(0,each_element[i].find(keyword));
            }
            //cout<<each_element[i]<<endl;
            each_element_set.push_back(each_element[i]);
        }
    }    
}

bool OUTCAR::Info_read(){
    string keyword_lattice("direct lattice vectors");
    string keyword_position("POSITION");
    bool ret=true;
    bool lattice_found=false;
    bool position_found=false;
    unsigned int i=0,j=0;
    vector<double> lattices;
    do{
        if (!getline(FILEs,each_line)) {
            ret=false;
            return ret;
        }
        if (each_line.find(keyword_lattice)!=string::npos){
            lattice_found=true;
            for (i=0;i<3;i++){
                getline(FILEs,each_line);
                split_data(each_line,&lattices);
                for (j=0;j<3;j++){
                    Lattice(i,j)=lattices[j];
                }
            }
            //cout<<Lattice<<endl;
        }
        else if (each_line.find(keyword_position)!=string::npos){
            position_found=true;
            getline(FILEs,each_line);
            for (i=0;i<ions_num;i++){
                getline(FILEs,each_line);
                split_data(each_line,&lattices);
                for (j=0;j<6;j++){
                    atomic_coord_force(i,j)=lattices[j];
                }
            }
            //cout<<atomic_coord_force<<endl;
        }
    } while(!lattice_found || !position_found); 
    return ret;   
}

OUTCAR::~OUTCAR(){
    FILEs.close();
    fclose(gro);
    fclose(top);
    fclose(mdp);
    mdp=NULL;
    gro=NULL;
    top=NULL;
}

void OUTCAR::write2GRO(int &frame){
    unsigned int i;
    int index=1;
    fprintf(gro,"t= %7.4f\n",dt*frame/1000.0); //ps
    fprintf(gro,"%5d\n",ions_num);
    // A/fs  ? ---> velocity (in nm/ps (or km/s)
    atomic_coord_prev=atomic_coord_prev/10.0; //A to nm
    atomic_velocity=atomic_velocity*100.0; //A/fs ->nm/ps  
    for (i=0;i<ions_num;i++){
        fprintf(gro,"%5d%-5s%5s%5d%8.3f%8.3f%8.3f%8.4f%8.4f%8.4f\n",index,"MOL",\
        each_element_set[i].data(),index,atomic_coord_prev(i,0),atomic_coord_prev(i,1)\
        ,atomic_coord_prev(i,2),atomic_velocity(i,0),atomic_velocity(i,1),atomic_velocity(i,2));
        index+=1;
    }
    Lattice=Lattice/10.0; //A to nm    
    fprintf(gro,"%8.4f%8.4f%8.4f%8.4f%8.4f%8.4f%8.4f%8.4f%8.4f\n",Lattice(0,0),Lattice(1,1),\
    Lattice(2,2),0.0,0.0,Lattice(1,0),0.0,Lattice(2,0),Lattice(2,1));
    //v1(x) v2(y) v3(z) v1(y) v1(z) v2(x) v2(z) v3(x) v3(y), the last 6 values may be omitted (they will be set to zero). GROMACS only supports boxes with v1(y)=v1(z)=v2(z)=0.
    atomic_coord_prev=atomic_coord_prev*10.0; // nm to A
}
void OUTCAR::writetopo(){
    unsigned int i,j,k;
    //int index=1;
    fprintf(top,"%s\n\n","; WARNING, it cannot be used for a simulation.");
    fprintf(top,"%s\n","[ defaults ]");
    fprintf(top,"%s\n","; nbfunc comb-rule gen-pairs fudgeLJ fudgeQQ");
    fprintf(top,"%s\n\n","1 3 yes 0.5 0.5");
    fprintf(top,"%s\n","[ atomtypes ]");
    fprintf(top,"%s\n","; name bond_type mass charge ptype sigma epsilon");
    for (i=0;i<each_element.size();i++){
            fprintf(top,"%s C 1.0 0.0 A 0.0 0.0\n",each_element[i].data());
        
    }
    fprintf(top,"\n%s\n","[ bondtypes ]");
    fprintf(top,"%s\n","; i j func b0 kb");
    fprintf(top,"%s\n\n","  C C 1 0.13 1000.0 ; totally bogus");
    fprintf(top,"%s\n","[ angletypes ]");
    fprintf(top,"%s\n%s\n\n","; i j k func th0 cth","  C C C 1 109.500 100.0 ; totally bogus");
    fprintf(top,"%s\n%s\n","[ dihedraltypes ]","; i j k l func coefficients");
    fprintf(top,"%s\n\n","  C C C C 1 0.0 3 10.0 ; totally bogus");    
    fprintf(top,"%s\n%s\n%s\n\n","[ moleculetype ]","; Name      nrexcl","molecule0     3");
    fprintf(top,"%s\n%s\n","[ atoms ]","; nr  type  resnr residue atom cgnr charge  mass");
    k=1;
    for (i=0;i<each_element.size();i++){
        for (j=0;j<each_element_num[i];j++){
            fprintf(top,"%6u%12s      1      MOL%7s%6u     0.0000%11.4f\n",k,each_element[i].data()\
            ,each_element[i].data(),k,each_element_mass[i]);
            k++;
        }
    }
    fprintf(top,"\n%s\n%s\n","[ bonds ]","; i  j  func");
    // for (i=1;i<each_element.size();i++){
    //     for (j=i+1;j<each_element.size()+1;j++){
    //         fprintf(top,"%u %u 1\n",i,j);
    //     }
    // }   
    fprintf(top,"\n"); 
    fprintf(top,"%s\n%s\n%s\n\n","[ system ]","; Name","Mymolecule0");
    fprintf(top,"%s\n%s\n%s\n\n","[ molecules ]","; Compound    #mols","molecule0    1");


    fprintf(mdp,"%s\n","; minim.mdp - used as input into grompp to generate em.tpr");
    fprintf(mdp,"%s\n","integrator  = steep     ; Algorithm (steep = steepest descent minimization)");
    fprintf(mdp,"%s\n","emtol       = 1000.0    ; Stop minimization when the maximum force < 1000.0 kJ/mol/nm");
    fprintf(mdp,"%s\n","emstep      = 0.01      ; Energy step size");
    fprintf(mdp,"%s\n","nsteps      = 50000     ; Maximum number of (minimization) steps to perform");
    fprintf(mdp,"%s\n","");
    fprintf(mdp,"%s\n","; Parameters describing how to find the neighbors of each atom and how to calculate the interactions");
    fprintf(mdp,"%s\n","nstlist         = 1         ; Frequency to update the neighbor list and long range forces");
    fprintf(mdp,"%s\n","cutoff-scheme   = Verlet");
    fprintf(mdp,"%s\n","ns_type         = grid      ; Method to determine neighbor list (simple, grid)");
    fprintf(mdp,"%s\n","coulombtype     = cut-off       ; Treatment of long range electrostatic interactions");
    fprintf(mdp,"%s\n","rcoulomb        = 0.01       ; Short-range electrostatic cut-off");
    fprintf(mdp,"%s\n","rvdw            = 0.01       ; Short-range Van der Waals cut-off");
    fprintf(mdp,"%s\n","pbc             = xyz       ; Periodic Boundary Conditions (yes/no)");
    fprintf(mdp,"%s\n","");


}

void OUTCAR::Process(){
    unsigned int i,j;
    int frame=0;
    this->Info_read();
    atomic_coord_prev=atomic_coord_force.block(0,0,ions_num,3); //initial
    atomic_coord_prve_unwrap=atomic_coord_force.block(0,0,ions_num,3);//fake coord
    while(this->Info_read()){
        //cout<<atomic_coord_force.block(0,0,ions_num,3)<<endl;
        atomic_dr=atomic_coord_force.block(0,0,ions_num,3)-atomic_coord_prve_unwrap; //dr
        atomic_coord_prve_unwrap=atomic_coord_force.block(0,0,ions_num,3);//To record fake coord
        for (i=0;i<3;i++){
            L[i]=sqrt(pow(Lattice(i,0),2)+pow(Lattice(i,1),2)+pow(Lattice(i,2),2));
        }
        //unwrap the coordinates and get the velocities:
        for (i=0;i<ions_num;i++){
            for (j=0;j<3;j++){
                atomic_dr(i,j)=atomic_dr(i,j)-round(atomic_dr(i,j)/L[j])*L_times_pbc[j]*L[j];
            }
        }        
        atomic_coord_prev=atomic_coord_prev+atomic_dr;
        atomic_velocity=atomic_dr/dt; //A/fs
        this->write2GRO(++frame);
    };
    this->writetopo();
    //http://blog.sciencenet.cn/blog-3102863-1159419.html
}

int main(int argc,char * argv[]){
    string file("OUTCAR");
    OUTCAR myOUTCAR(file);
    myOUTCAR.Process();
    return 0;
}
